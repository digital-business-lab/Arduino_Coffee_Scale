# Changelog

## 1.0.4 (release)

adjust image responsive scaling

## 1.0.3 (release)

add workflow

## 1.0.2 (release)

release file modify

## 1.0.1 (Unreleased)

Add Some Options

## 1.0.0 (Unreleased)

Initial release.